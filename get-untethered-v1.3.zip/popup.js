// Get Untethered v1.3 — popup (uses shared classify.js)

let DICT = {};

async function loadTheme() {
  // Apply saved theme BEFORE making body visible, to prevent a flash of the wrong theme.
  try {
    const { theme } = await chrome.storage.local.get("theme");
    document.documentElement.dataset.theme = theme === "light" ? "light" : "dark";
  } catch (e) {
    document.documentElement.dataset.theme = "dark";
  }
}

function wireThemeToggle() {
  const btn = document.getElementById("theme-toggle");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const current = document.documentElement.dataset.theme === "light" ? "light" : "dark";
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try {
      await chrome.storage.local.set({ theme: next });
    } catch (e) {}
  });
}

async function loadDict() {
  try {
    const res = await fetch(chrome.runtime.getURL("dictionary.json"));
    DICT = await res.json();
  } catch (e) {
    DICT = {};
  }
}

async function render() {
  const content = document.getElementById("content");
  const siteEl = document.getElementById("site");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    content.innerHTML = '<div class="empty">No active tab.</div>';
    return;
  }

  const store = await chrome.storage.session.get("tab_" + tab.id);
  const data = store["tab_" + tab.id];

  if (!data || !data.firstParty) {
    siteEl.textContent = "—";
    content.innerHTML =
      '<div class="empty">Nothing scanned yet.<br><br>Reload this page, then reopen. (The scan only sees requests made while it\'s watching.)</div>';
    return;
  }

  siteEl.textContent = data.firstParty;

  const { buckets, topTier } = self.classify(data.thirds, DICT);
  const v = self.VERDICTS[topTier];

  let html = "";
  html += '<div class="light"><div class="dot ' + topTier + '"></div>';
  html += '<div class="verdict"><div class="label">' + v.label + '</div><div class="sub">' + v.sub + "</div></div></div>";

  html += '<div class="groups">';
  for (const groupId of self.GROUP_ORDER) {
    const list = buckets[groupId];
    if (!list.length) continue;
    list.sort((a, b) => a.owner.localeCompare(b.owner));
    const g = self.GROUPS[groupId];
    const openByDefault = groupId === "personal-profiling" || groupId === "security-identity";
    html += '<div class="group' + (openByDefault ? " open" : "") + '">';
    html += '<button class="group-head"><span><span class="tier-dot ' + g.dot + '"></span>' + g.label + "</span>";
    html += '<span><span class="count">' + list.length + '</span> <span class="chev">&#9656;</span></span></button>';
    html += '<div class="group-body">';
    for (const o of list) {
      const tag = o.items.length > 1 ? ' <span class="tag">' + o.items.length + " domains</span>" : "";
      html += '<div class="item"><div class="who">' + escapeHtml(o.owner) + tag + '</div><div class="what">' + escapeHtml(o.items[0].text) + "</div></div>";
    }
    html += "</div></div>";
  }
  html += "</div>";

  content.innerHTML = html;

  document.querySelectorAll(".group-head").forEach((btn) => {
    btn.addEventListener("click", () => btn.parentElement.classList.toggle("open"));
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

(async () => {
  await loadTheme();
  document.body.classList.add("ready");
  await loadDict();
  await render();
  wireThemeToggle();
})();
