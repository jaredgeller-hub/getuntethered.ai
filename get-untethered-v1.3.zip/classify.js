// classify.js — shared by background (icon) and popup (detail view).
// Attaches to `self` so it works in both the service worker and the popup window.

self.CATEGORY_GROUP = {
  "first-party": "running-site",
  "payment": "running-site",
  "infrastructure": "running-site",
  "consent": "running-site",
  "utility": "running-site",
  "support": "running-site",
  "tag-manager": "ad-tracking",
  "analytics": "ad-tracking",
  "behavioral-analytics": "ad-tracking",
  "advertising": "ad-tracking",
  "marketing": "ad-tracking",
  "measurement": "ad-tracking",
  "mixed": "ad-tracking",
  "partner": "ad-tracking",
  "fraud-identity": "security-identity",
  "personalization": "personal-profiling",
  "identity-resolution": "personal-profiling",
  "data-broker": "personal-profiling",
  "unverified": "unknown"
};

self.GROUPS = {
  "personal-profiling": { label: "Personal profiling", dot: "red", light: "red" },
  "security-identity": { label: "Security & identity (dual-use)", dot: "orange", light: "yellow" },
  "ad-tracking": { label: "Ad & behavior tracking", dot: "yellow", light: "yellow" },
  "running-site": { label: "Running the site", dot: "green", light: "green" },
  "unknown": { label: "Unknown", dot: "grey", light: null }
};

self.GROUP_ORDER = ["personal-profiling", "security-identity", "ad-tracking", "running-site", "unknown"];
self.LIGHT_RANK = { green: 0, yellow: 1, red: 2 };

self.VERDICTS = {
  green: {
    label: "Just running the store",
    sub: "Only the site's own systems, payments, and infrastructure. No outside profiling detected."
  },
  yellow: {
    label: "You're being tracked",
    sub: "Outside companies are watching or fingerprinting what you do here — for ads, analytics, or fraud detection."
  },
  red: {
    label: "You're being personally profiled",
    sub: "Personalization or data-broker tech is active — the machinery behind individualized targeting and pricing. (We can't see whether your price was changed, only that this tech is present.)"
  }
};

// thirds: { domain: count }, dict: { domain: {owner, category, text} }
// returns { buckets, topTier }
self.classify = function (thirds, dict) {
  const owners = {};
  for (const domain of Object.keys(thirds || {})) {
    const entry = dict && dict[domain];
    let owner, group, text;
    if (entry) {
      owner = entry.owner || domain;
      group = self.CATEGORY_GROUP[entry.category] || "unknown";
      text = entry.text;
    } else {
      owner = domain;
      group = "unknown";
      text = "Not yet identified — an outside domain we don't have a name for.";
    }
    const key = group + "|" + owner;
    if (!owners[key]) owners[key] = { owner, group, items: [] };
    owners[key].items.push({ text });
  }
  const buckets = { "personal-profiling": [], "security-identity": [], "ad-tracking": [], "running-site": [], "unknown": [] };
  let topTier = "green";
  for (const o of Object.values(owners)) {
    buckets[o.group].push(o);
    const lt = self.GROUPS[o.group].light;
    if (lt && self.LIGHT_RANK[lt] > self.LIGHT_RANK[topTier]) topTier = lt;
  }
  return { buckets, topTier };
};
