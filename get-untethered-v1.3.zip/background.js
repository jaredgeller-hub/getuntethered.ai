// Untethered v1.2 — background service worker
importScripts("classify.js");

let DICT = null;
fetch(chrome.runtime.getURL("dictionary.json"))
  .then((r) => r.json())
  .then((d) => {
    DICT = d;
    // Catch up any tabs already scanned before the dictionary finished loading.
    for (const id in tabData) refresh(Number(id));
  })
  .catch(() => { DICT = {}; });

const tabData = {};   // tabId -> { firstParty, thirds:{domain:count} }
const lastTier = {};  // tabId -> last painted tier (to avoid redundant repaints)

function getDomain(url) {
  try {
    const host = new URL(url).hostname;
    if (!host) return null;
    const parts = host.split(".");
    if (parts.length <= 2) return host;
    return parts.slice(-2).join(".");
  } catch (e) {
    return null;
  }
}

const ICON_COLORS = { red: "#f04438", yellow: "#e3b341", green: "#3fb950", grey: "#5a534c" };

function makeIcon(color) {
  const size = 32;
  const c = new OffscreenCanvas(size, size);
  const ctx = c.getContext("2d");
  ctx.clearRect(0, 0, size, size);
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size / 2 - 2, 0, 2 * Math.PI);
  ctx.fillStyle = color;
  ctx.fill();
  // subtle dark ring for contrast on light toolbars
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(0,0,0,0.25)";
  ctx.stroke();
  return ctx.getImageData(0, 0, size, size);
}

function paint(tabId, key) {
  const color = ICON_COLORS[key] || ICON_COLORS.grey;
  try {
    chrome.action.setIcon({ tabId, imageData: { 32: makeIcon(color) } });
  } catch (e) {}
  let title = "Get Untethered — who's watching";
  if (self.VERDICTS[key]) title = "Get Untethered — " + self.VERDICTS[key].label;
  else if (key === "grey") title = "Get Untethered — scanning…";
  chrome.action.setTitle({ tabId, title });
}

function refresh(tabId) {
  if (!DICT) return;
  const entry = tabData[tabId];
  if (!entry) return;
  const { topTier } = self.classify(entry.thirds, DICT);
  if (lastTier[tabId] !== topTier) {
    lastTier[tabId] = topTier;
    paint(tabId, topTier);
  }
}

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const tabId = details.tabId;
    if (tabId < 0) return;

    if (details.type === "main_frame") {
      tabData[tabId] = { firstParty: getDomain(details.url), thirds: {} };
      lastTier[tabId] = "grey";
      paint(tabId, "grey"); // neutral until we've seen enough to classify
      chrome.storage.session.set({ ["tab_" + tabId]: tabData[tabId] });
      return;
    }

    let entry = tabData[tabId];
    if (!entry) entry = tabData[tabId] = { firstParty: null, thirds: {} };

    const d = getDomain(details.url);
    if (!d) return;
    if (entry.firstParty && d === entry.firstParty) return;

    entry.thirds[d] = (entry.thirds[d] || 0) + 1;
    chrome.storage.session.set({ ["tab_" + tabId]: entry });
    refresh(tabId);
  },
  { urls: ["<all_urls>"] }
);

chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabData[tabId];
  delete lastTier[tabId];
  chrome.storage.session.remove("tab_" + tabId);
});
